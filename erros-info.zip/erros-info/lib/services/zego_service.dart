import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import 'package:zego_uikit_signaling_plugin/zego_uikit_signaling_plugin.dart';

class ZegoService {
  static const int appId = 1478106327;
  static const String appSign = 'fba5f1af2f4adcf421d40a3c32897b7aaf5cbb5c5ab26dc33d4a6056e8005c91';
  static const String serverSecret = '90eee9ce759b1eacd3a30e0bdcc7755a';

  /// Initialize ZegoCloud Call Invitation Service
  static Future<void> init(String userId, String userName) async {
    // Ensure all plugins are registered correctly
    ZegoUIKitPrebuiltCallInvitationService().init(
      appID: appId,
      appSign: appSign,
      userID: userId,
      userName: userName,
      plugins: [ZegoUIKitSignalingPlugin()],
    );
  }

  /// Uninit ZegoCloud Service
  static void uninit() {
    ZegoUIKitPrebuiltCallInvitationService().uninit();
  }
}
