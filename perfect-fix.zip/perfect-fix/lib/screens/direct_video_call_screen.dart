import 'package:flutter/material.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../utils/constants.dart';

class DirectVideoCallScreen extends StatelessWidget {
  final String callId;
  final String matchId;
  final String channelName;
  final String partnerUid;
  final String partnerName;
  final String partnerAvatar;
  final bool isOutgoing;

  const DirectVideoCallScreen({
    super.key,
    required this.callId,
    required this.matchId,
    required this.channelName,
    required this.partnerUid,
    required this.partnerName,
    this.partnerAvatar = '',
    this.isOutgoing = true,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthProvider>();
    final myUid = auth.firebaseUser?.uid ?? 'unknown';
    final myName = auth.userModel?.name ?? 'User';

    return ZegoUIKitPrebuiltCall(
      appID: AppConstants.zegoAppId,
      appSign: AppConstants.zegoAppSign,
      userID: myUid,
      userName: myName,
      callID: channelName,
      config: ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
        ..onHangUp = () {
          Navigator.of(context).pop();
        },
    );
  }
}
