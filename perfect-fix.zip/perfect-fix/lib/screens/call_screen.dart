import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import '../config/app_colors.dart';
import '../providers/auth_provider.dart';
import '../providers/call_provider.dart';
import '../widgets/searching_animation.dart';
import '../utils/constants.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key});

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  @override
  Widget build(BuildContext context) {
    final call = context.watch<CallProvider>();
    final auth = context.read<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.callBackground,
      body: Stack(
        children: [
          if (call.state == CallState.connected && call.currentMatch != null)
            Positioned.fill(
              child: ZegoUIKitPrebuiltCall(
                appID: AppConstants.zegoAppId,
                appSign: AppConstants.zegoAppSign,
                userID: auth.userModel!.uid,
                userName: auth.userModel!.name,
                callID: call.currentMatch!.matchId,
                config: ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
                  ..topMenuBar.isVisible = true
                  ..onHangUp = () {
                    call.nextPartner(auth.userModel!);
                  },
              ),
            )
          else
            Positioned.fill(
              child: SearchingAnimation(isConnecting: call.state == CallState.connecting),
            ),

          if (call.state == CallState.searching || call.state == CallState.connecting)
            Positioned(
              bottom: MediaQuery.of(context).padding.bottom + 24,
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                   Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextButton.icon(
                      onPressed: () async {
                        await call.stopCompletely(auth.firebaseUser!.uid);
                        if (context.mounted) context.go('/home');
                      },
                      icon: const Icon(Icons.close, color: Colors.white54, size: 18),
                      label: const Text('Cancel Search', style: TextStyle(color: Colors.white54, fontSize: 15)),
                    ),
                  ),
                ],
              ),
            ),
            
          if (call.state == CallState.connected)
            Positioned(
              top: MediaQuery.of(context).padding.top + 10,
              right: 16,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  foregroundColor: Colors.white,
                ),
                onPressed: () => call.nextPartner(auth.userModel!),
                icon: const Icon(Icons.skip_next),
                label: const Text("Next"),
              ),
            ),
        ],
      ),
    );
  }
}
